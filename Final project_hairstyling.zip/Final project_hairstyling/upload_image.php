<?php
session_start();
include 'db.php';

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: /Final%20project_hairstyling/login.html');
    exit();
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_SESSION['user_id'];
    $description = $conn->real_escape_string($_POST['description']);

    // Define the upload directory
    $target_dir = "../uploads/";
    
    // Check if uploads directory exists
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true); // Create it if it doesn't exist
    }

    // Get file details
    $imageFileType = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];

    // Validate file type
    if (!in_array($imageFileType, $allowed_extensions)) {
        die("Only JPG, JPEG, PNG, and GIF files are allowed.");
    }

    // Sanitize file name and create unique file name
    $filename = uniqid() . '.' . $imageFileType;
    $target_file = $target_dir . $filename;

    // Validate image
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if ($check === false) {
        die("File is not an image.");
    }

    // Move the uploaded file
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        // Save file information to the database
        $db_file_path = '/uploads/' . $filename; // Relative path for database
        $sql = "INSERT INTO UploadedImages (user_id, image_url, description) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iss", $user_id, $db_file_path, $description);

        if ($stmt->execute()) {
            echo "Image uploaded successfully. <a href='profile.php'>Go back to profile</a>";
        } else {
            echo "Database error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

$conn->close();
?>
