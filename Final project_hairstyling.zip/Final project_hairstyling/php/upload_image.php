<?php
session_start();
include 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: /Final%20project_hairstyling/login.html');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_SESSION['user_id'];
    $description = $conn->real_escape_string($_POST['description']);
    
    // Handle the uploaded file
    $target_dir = "../uploads/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if file is an image
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if ($check === false) {
        die("File is not an image.");
    }

    // Move the uploaded file to the uploads folder
    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        // Save file information to the database
        $sql = "INSERT INTO UploadedImages (user_id, image_url, description) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("iss", $user_id, $target_file, $description);
        if ($stmt->execute()) {
            echo "Image uploaded successfully. <a href='profile.php'>Go back to profile</a>";
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

$conn->close();
?>
