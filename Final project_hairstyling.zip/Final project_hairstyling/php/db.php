<?php
// Database credentials
$host = "localhost"; // Database server (use "localhost" for local development)
$username = "mahak"; // Replace with your database username
$password = "123"; // Replace with your database password
$database = "hairstylingapp"; // Replace with your database name

// Create a connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


?>
