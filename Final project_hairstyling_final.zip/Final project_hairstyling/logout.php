<?php
session_start();
session_destroy();

// Redirect to the absolute path of login.html
header('Location: /Final%20project_hairstyling/login.html');
exit();
?>
