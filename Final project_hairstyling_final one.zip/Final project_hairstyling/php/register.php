<?php
// Include the database connection file
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve form data and sanitize inputs
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password securely
    $hair_length = $conn->real_escape_string($_POST['hair_length']);
    $hair_texture = $conn->real_escape_string($_POST['hair_texture']);
    $preferences = $conn->real_escape_string($_POST['preferences']);

    // Check if the email already exists
    $check_email_query = "SELECT email FROM Users WHERE email = ?";
    $stmt = $conn->prepare($check_email_query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo "Email already exists. Please use a different email.";
    } else {
        // Insert the user into the database
        $insert_query = "INSERT INTO Users (name, email, password, hair_length, hair_texture, preferences) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("ssssss", $name, $email, $password, $hair_length, $hair_texture, $preferences);

        if ($stmt->execute()) {
            echo "Registration successful! You can now log in.";
        } else {
            echo "Error: " . $stmt->error;
        }
    }

    $stmt->close();
    $conn->close();
}
?>
