<?php
session_start();
include 'db.php';

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.html');
    exit();
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_SESSION['user_id']; // Assuming user_id is stored in the session
    $salon_id = intval($_POST['salon_id']);
    $hairstyle_id = intval($_POST['hairstyle_id']);
    $rating = floatval($_POST['rating']);
    $review_text = $conn->real_escape_string($_POST['review_text']);

    // Validate hairstyle_id exists in hairstyles table
    $hairstyle_check_sql = "SELECT id FROM hairstyles WHERE id = ?";
    $hairstyle_check_stmt = $conn->prepare($hairstyle_check_sql);
    $hairstyle_check_stmt->bind_param("i", $hairstyle_id);
    $hairstyle_check_stmt->execute();
    $hairstyle_check_result = $hairstyle_check_stmt->get_result();

    if ($hairstyle_check_result->num_rows === 0) {
        die("Error: The selected hairstyle does not exist. Please choose a valid hairstyle.");
    }

    // Insert review into the database
    $sql = "INSERT INTO reviews (user_id, salon_id, hairstyle_id, rating, review_text) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("iiids", $user_id, $salon_id, $hairstyle_id, $rating, $review_text);

    if ($stmt->execute()) {
        echo "Review submitted successfully. <a href='/Final%20project_hairstyling/php/profile.php'>Go back to profile</a>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
