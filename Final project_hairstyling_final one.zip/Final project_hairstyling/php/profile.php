<?php
session_start();
include 'db.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit();
}

// Get logged-in user's ID and name
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];

// Fetch user's images from the database
$sql = "SELECT image_url, description FROM UploadedImages WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($user_name); ?>'s Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        header {
            background-color: #4CAF50;
            color: white;
            text-align: center;
            padding: 1rem 0;
        }

        header h1 {
            margin: 0;
        }

        nav {
            text-align: center;
            margin-top: 0.5rem;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 1rem;
            font-size: 1rem;
        }

        nav a:hover {
            text-decoration: underline;
        }

        section {
            max-width: 800px;
            margin: 2rem auto;
            background: white;
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .image-gallery {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            justify-content: center;
        }

        .image-item {
            text-align: center;
            max-width: 200px;
        }

        .image-item img {
            width: 100%;
            border-radius: 8px;
            border: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <header>
        <h1>Welcome, <?php echo htmlspecialchars($user_name); ?>!</h1>
        <nav>
            <a href="logout.php">🔓 Logout</a>
        </nav>
    </header>
    <section>
        <h2>Your Images</h2>
        <div class="image-gallery">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="image-item">
                        <img src="<?php echo htmlspecialchars('/Final%20project_hairstyling' . $row['image_url']); ?>" alt="Uploaded Image">
                        <p><?php echo htmlspecialchars($row['description']); ?></p>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>You have not uploaded any images yet.</p>
            <?php endif; ?>
        </div>
    </section>
    <footer>
        <p>© 2024 Hairstyling Recommendation App</p>
    </footer>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
