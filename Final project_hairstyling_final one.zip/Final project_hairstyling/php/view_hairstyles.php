<?php
// Database connection
include 'db.php'; // Ensure your 'db.php' is correctly configured

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Fetch hairstyles data
$sql = "SELECT id, name, description, hair_length_suitable, hair_texture_suitable, tutorial_id, created_at FROM hairstyles";
$result = $conn->query($sql);

// Generate table rows
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . htmlspecialchars($row['id']) . "</td>
                <td>" . htmlspecialchars($row['name']) . "</td>
                <td>" . htmlspecialchars($row['description']) . "</td>
                <td>" . htmlspecialchars($row['hair_length_suitable'] ?? 'N/A') . "</td>
                <td>" . htmlspecialchars($row['hair_texture_suitable'] ?? 'N/A') . "</td>
                <td>" . htmlspecialchars($row['tutorial_id'] ?? 'N/A') . "</td>
                <td>" . htmlspecialchars($row['created_at']) . "</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='7' style='text-align: center;'>No records found</td></tr>";
}

// Close the database connection
$conn->close();
?>
