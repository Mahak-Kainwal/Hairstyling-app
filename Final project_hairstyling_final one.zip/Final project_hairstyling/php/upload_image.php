<?php
session_start();
include 'db.php';

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: /Final%20project_hairstyling/login.html');
    exit();
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_SESSION['user_id'];
    $description = $conn->real_escape_string($_POST['description']);

    // Define the upload directory
    $target_dir = "../uploads/";
    
    // Ensure the uploads directory exists
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    // Get file details
    $imageFileType = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];

    // Validate file type
    if (!in_array($imageFileType, $allowed_extensions)) {
        echo "<html><body style='text-align: center; font-family: Arial, sans-serif;'>
                <p>Error: Only JPG, JPEG, PNG, and GIF files are allowed.</p>
                <a href='upload_image.html'>Go back to upload image</a>
              </body></html>";
        exit();
    }

    // Sanitize file name and create a unique file name
    $filename = uniqid() . '.' . $imageFileType;
    $target_file = $target_dir . $filename;

    // Validate and move the uploaded file
    if (is_uploaded_file($_FILES["image"]["tmp_name"]) && move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        // Save file information to the database
        $db_file_path = '/uploads/' . $filename; // Relative path for database
        $sql = "INSERT INTO UploadedImages (user_id, image_url, description) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("iss", $user_id, $db_file_path, $description);
            if ($stmt->execute()) {
                echo "<html><body style='text-align: center; font-family: Arial, sans-serif;'>
                        <p>Image uploaded successfully. <a href='profile.php'>Go back to profile</a></p>
                      </body></html>";
            } else {
                echo "<html><body style='text-align: center; font-family: Arial, sans-serif;'>
                        <p>Error: Could not save image information in the database.</p>
                        <a href='upload_image.html'>Go back to upload image</a>
                      </body></html>";
            }
            $stmt->close();
        } else {
            echo "<html><body style='text-align: center; font-family: Arial, sans-serif;'>
                    <p>Error: Unable to prepare database statement.</p>
                    <a href='upload_image.html'>Go back to upload image</a>
                  </body></html>";
        }
    } else {
        echo "<html><body style='text-align: center; font-family: Arial, sans-serif;'>
                <p>Error: Failed to upload the file.</p>
                <a href='upload_image.html'>Go back to upload image</a>
              </body></html>";
    }
}

$conn->close();
?>
