<?php
session_start();
include 'db.php';

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: /Final%20project_hairstyling/login.html');
    exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $user_id = $_SESSION['user_id']; // Assuming user_id is stored in session
    $salon_id = intval($_POST['salon_id']);
    $appointment_date = $_POST['appointment_date'];
    $service = $conn->real_escape_string($_POST['service']);
    $status = 'Pending'; // Default status

    // Validate salon_id
    $salon_check_sql = "SELECT id FROM salons WHERE id = ?";
    $salon_check_stmt = $conn->prepare($salon_check_sql);
    $salon_check_stmt->bind_param("i", $salon_id);
    $salon_check_stmt->execute();
    $salon_check_result = $salon_check_stmt->get_result();

    if ($salon_check_result->num_rows === 0) {
        die("Error: Salon ID does not exist. Please choose a valid salon.");
    }

    // Insert appointment details into the database
    $sql = "INSERT INTO bookings (user_id, salon_id, service, appointment_date, status) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("Error in SQL preparation: " . $conn->error);
    }

    $stmt->bind_param("iisss", $user_id, $salon_id, $service, $appointment_date, $status);

    if ($stmt->execute()) {
        echo "Appointment booked successfully. <a href='/Final%20project_hairstyling/php/profile.php'>Go back to profile</a>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
