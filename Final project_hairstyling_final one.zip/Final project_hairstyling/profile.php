<?php
session_start();
include 'db.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html'); // Redirect to login if not logged in
    exit();
}

// Get logged-in user's ID and name
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];

// Fetch user's images from the database
$sql = "SELECT * FROM Images WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $user_name; ?>'s Profile</title>
    <link rel="stylesheet" href="C:\Users\mahak\OneDrive\Documents\Desktop\Final project\css\style.css">
</head>
<body>
    <header>
        <h1>Welcome, <?php echo htmlspecialchars($user_name); ?>!</h1>
        <nav>
            <a href="logout.php">🔓 Logout</a>
        </nav>
    </header>
    <section>
        <h2>Your Images</h2>
        <div class="image-gallery">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="image-item">
                        <img src="<?php echo htmlspecialchars($row['image_url']); ?>" alt="User Image">
                        <p><?php echo htmlspecialchars($row['description']); ?></p>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>You have not uploaded any images yet.</p>
            <?php endif; ?>
        </div>
    </section>
    <footer>
        <p>© 2024 Hairstyling Recommendation App</p>
    </footer>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
